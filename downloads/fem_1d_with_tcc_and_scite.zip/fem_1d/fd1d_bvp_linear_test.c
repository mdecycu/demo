# include <math.h>
# include <stdio.h>
# include <stdlib.h>
# include <string.h>

double *fem1d_bvp_linear ( int n, double a ( double x ), double c ( double x ), 
  double f ( double x ), double x[] );
double h1s_error_linear ( int n, double x[], double u[], 
  double exact_ux ( double x ) );
int i4_power ( int i, int j );
int *i4vec_zero_new ( int n );
double l1_error ( int n, double x[], double u[], 
  double exact ( double x ) );
double l2_error_linear ( int n, double x[], double u[], 
  double exact ( double x ) );
double max_error_linear ( int n, double x[], double u[], 
  double exact ( double x ) );
double r8_max ( double x, double y );
double *r8mat_solve2 ( int n, double a[], double b[], int *ierror );
double *r8mat_zero_new ( int m, int n );
double *r8vec_linspace_new ( int n, double alo, double ahi );
double *r8vec_zero_new ( int n );
void timestamp ( );

/******************************************************************************/

double *fem1d_bvp_linear ( int n, double a ( double x ), double c ( double x ), 
  double f ( double x ), double x[] )

/******************************************************************************/
/*
  Purpose:

    FEM1D_BVP_LINEAR solves a two point boundary value problem.

  Location:

    http://people.sc.fsu.edu/~jburkardt/c_src/fem1d_bvp_linear/fem1d_bvp_linear.c

  Discussion:

    The program uses the finite element method, with piecewise linear basis
    functions to solve a boundary value problem in one dimension.

    The problem is defined on the region 0 <= x <= 1.

    The following differential equation is imposed between 0 and 1:

      - d/dx a(x) du/dx + c(x) * u(x) = f(x)

    where a(x), c(x), and f(x) are given functions.

    At the boundaries, the following conditions are applied:

      u(0.0) = 0.0
      u(1.0) = 0.0

    A set of N equally spaced nodes is defined on this
    interval, with 0 = X(1) < X(2) < ... < X(N) = 1.0.

    At each node I, we associate a piecewise linear basis function V(I,X),
    which is 0 at all nodes except node I.  This implies that V(I,X) is
    everywhere 0 except that

    for X(I-1) <= X <= X(I):

      V(I,X) = ( X - X(I-1) ) / ( X(I) - X(I-1) ) 

    for X(I) <= X <= X(I+1):

      V(I,X) = ( X(I+1) - X ) / ( X(I+1) - X(I) )

    We now assume that the solution U(X) can be written as a linear
    sum of these basis functions:

      U(X) = sum ( 1 <= J <= N ) U(J) * V(J,X)

    where U(X) on the left is the function of X, but on the right,
    is meant to indicate the coefficients of the basis functions.

    To determine the coefficient U(J), we multiply the original
    differential equation by the basis function V(J,X), and use
    integration by parts, to arrive at the I-th finite element equation:

        Integral A(X) * U'(X) * V'(I,X) + C(X) * U(X) * V(I,X) dx 
      = Integral F(X) * V(I,X) dx

    We note that the functions U(X) and U'(X) can be replaced by
    the finite element form involving the linear sum of basis functions,
    but we also note that the resulting integrand will only be nonzero
    for terms where J = I - 1, I, or I + 1.

    By writing this equation for basis functions I = 2 through N - 1,
    and using the boundary conditions, we have N linear equations
    for the N unknown coefficients U(1) through U(N), which can
    be easily solved.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    18 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, int N, the number of nodes.

    Input, double A ( double X ), evaluates a(x);

    Input, double C ( double X ), evaluates c(x);

    Input, double F ( double X ), evaluates f(x);

    Input, double X[N], the mesh points.

    Output, double FEM1D_BVP_LINEAR[N], the finite element coefficients, 
    which are also the value of the computed solution at the mesh points.
*/
{
# define QUAD_NUM 2

  double abscissa[QUAD_NUM] = {
    -0.577350269189625764509148780502,
    +0.577350269189625764509148780502 };
  double *amat;
  double axq;
  double *b;
  double cxq;
  int e;
  int e_num;
  double fxq;
  int i;
  int ierror;
  int j;
  int l;
  int q;
  int quad_num = QUAD_NUM;
  int r;
  double *u;
  double weight[QUAD_NUM] = { 1.0, 1.0 };
  double wq;
  double vl;
  double vlp;
  double vr;
  double vrp;
  double xl;
  double xq;
  double xr;
/*
  Zero out the matrix and right hand side.
*/
  amat = r8mat_zero_new ( n, n );
  b = r8vec_zero_new ( n );

  e_num = n - 1;

  for ( e = 0; e < e_num; e++ )
  {
    l = e;
    r = e + 1;

    xl = x[l];
    xr = x[r];

    for ( q = 0; q < quad_num; q++ )
    {
      xq = ( ( 1.0 - abscissa[q] ) * xl   
           + ( 1.0 + abscissa[q] ) * xr ) 
           /   2.0;

      wq = weight[q] * ( xr - xl ) / 2.0;

      vl =  ( xr - xq ) / ( xr - xl );
      vlp =      - 1.0  / ( xr - xl );

      vr =  ( xq - xl ) / ( xr - xl );
      vrp =  + 1.0      / ( xr - xl );

      axq = a ( xq );
      cxq = c ( xq );
      fxq = f ( xq );

      amat[l+l*n] = amat[l+l*n] + wq * ( vlp * axq * vlp + vl * cxq * vl );
      amat[l+r*n] = amat[l+r*n] + wq * ( vlp * axq * vrp + vl * cxq * vr );
      b[l]        = b[l]        + wq * ( vl * fxq );

      amat[r+l*n] = amat[r+l*n] + wq * ( vrp * axq * vlp + vr * cxq * vl );
      amat[r+r*n] = amat[r+r*n] + wq * ( vrp * axq * vrp + vr * cxq * vr );
      b[r]        = b[r]        + wq * ( vr * fxq );
    }
  }
/*
  Equation 1 is the left boundary condition, U(0.0) = 0.0;
*/
  for ( j = 0; j < n; j++ )
  {
    amat[0+j*n] = 0.0;
  }
  b[0] = 0.0;
  for ( i = 1; i < n; i++ )
  {
    b[i] = b[i] - amat[i+0*n] * b[0];
  }
  for ( i = 0; i < n; i++ )
  {
    amat[i+0*n] = 0.0;
  }
  amat[0+0*n] = 1.0;
/*
  Equation N is the right boundary condition, U(1.0) = 0.0;
*/
  for ( j = 0; j < n; j++ )
  {
    amat[n-1+j*n] = 0.0;
  }
  b[n-1] = 0.0;
  for ( i = 0; i < n - 1; i++ )
  {
    b[i] = b[i] - amat[i+(n-1)*n] * b[n-1];
  }
  for ( i = 0; i < n; i++ )
  {
    amat[i+(n-1)*n] = 0.0;
  }
  amat[n-1+(n-1)*n] = 1.0;
/*
  Solve the linear system.
*/
  u = r8mat_solve2 ( n, amat, b, &ierror );

  free ( amat );
  free ( b );

  return u;
# undef QUAD_NUM
}
/******************************************************************************/

double h1s_error_linear ( int n, double x[], double u[], 
  double exact_ux ( double x ) )

/******************************************************************************/
/*
  Purpose:

    H1S_ERROR_LINEAR estimates the seminorm error of a finite element solution.

  Discussion:

    We assume the finite element method has been used, over an interval [A,B]
    involving N nodes, with piecewise linear elements used for the basis.

    The coefficients U(1:N) have been computed, and a formula for the
    exact derivative is known.

    This function estimates the seminorm of the error:

      SEMINORM = Integral ( A <= X <= B ) ( dU(X)/dx - EXACT_UX(X) )^2 dX

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    18 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, int N, the number of nodes.

    Input, double X(N), the mesh points.

    Input, double U(N), the finite element coefficients.

    Input, function EQ = EXACT_UX ( X ), returns the value of the exact
    derivative at the point X.

    Output, double H1S_ERROR_LINEAR, the estimated seminorm of 
    the error.
*/
{
# define QUAD_NUM 2

  double abscissa[QUAD_NUM] = {
    -0.577350269189625764509148780502,
    +0.577350269189625764509148780502 };
  double exq;
  double h1s;
  int i;
  int q;
  int quad_num = QUAD_NUM;
  double ul;
  double ur;
  double uxq;
  double weight[QUAD_NUM] = { 1.0, 1.0 };
  double wq;
  double xl;
  double xq;
  double xr;

  h1s = 0.0;
/*
  Integrate over each interval.
*/
  for ( i = 0; i < n - 1; i++ )
  {
    xl = x[i];
    xr = x[i+1];
    ul = u[i];
    ur = u[i+1];

    for ( q = 0; q < quad_num; q++ )
    {
      xq = ( ( 1.0 - abscissa[q] ) * xl   
           + ( 1.0 + abscissa[q] ) * xr ) 
           /   2.0;

      wq = weight[q] * ( xr - xl ) / 2.0;
/*
  The piecewise linear derivative is a constant in the interval.
*/
      uxq = ( ur - ul ) / ( xr - xl );

      exq = exact_ux ( xq );
 
      h1s = h1s + wq * pow ( uxq - exq, 2);
    }
  }
  h1s = sqrt ( h1s );

  return h1s;
# undef QUAD_NUM
}
/******************************************************************************/

int i4_power ( int i, int j )

/******************************************************************************/
/*
  Purpose:

    I4_POWER returns the value of I^J.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    23 October 2007

  Author:

    John Burkardt

  Parameters:

    Input, int I, J, the base and the power.  J should be nonnegative.

    Output, int I4_POWER, the value of I^J.
*/
{
  int k;
  int value;

  if ( j < 0 )
  {
    if ( i == 1 )
    {
      value = 1;
    }
    else if ( i == 0 )
    {
      fprintf ( stderr, "\n" );
      fprintf ( stderr, "I4_POWER - Fatal error!\n" );
      fprintf ( stderr, "  I^J requested, with I = 0 and J negative.\n" );
      exit ( 1 );
    }
    else
    {
      value = 0;
    }
  }
  else if ( j == 0 )
  {
    if ( i == 0 )
    {
      fprintf ( stderr, "\n" );
      fprintf ( stderr, "I4_POWER - Fatal error!\n" );
      fprintf ( stderr, "  I^J requested, with I = 0 and J = 0.\n" );
      exit ( 1 );
    }
    else
    {
      value = 1;
    }
  }
  else if ( j == 1 )
  {
    value = i;
  }
  else
  {
    value = 1;
    for ( k = 1; k <= j; k++ )
    {
      value = value * i;
    }
  }
  return value;
}
/******************************************************************************/

int *i4vec_zero_new ( int n )

/******************************************************************************/
/*
  Purpose:

    I4VEC_ZERO_NEW creates and zeroes an I4VEC.

  Discussion:

    An I4VEC is a vector of I4's.

  Licensing:

    This code is distributed under the GNU LGPL license. 

  Modified:

    05 September 2008

  Author:

    John Burkardt

  Parameters:

    Input, int N, the number of entries in the vector.

    Output, int I4VEC_ZERO_NEW[N], a vector of zeroes.
*/
{
  int *a;
  int i;

  a = ( int * ) malloc ( n * sizeof ( int ) );

  for ( i = 0; i < n; i++ )
  {
    a[i] = 0;
  }
  return a;
}
/******************************************************************************/

double l1_error ( int n, double x[], double u[], double exact ( double x ) )

/******************************************************************************/
/*
  Purpose:

    L1_ERROR estimates the l1 error norm of a finite element solution.

  Discussion:

    We assume the finite element method has been used, over an interval [A,B]
    involving N nodes.

    The coefficients U(1:N) have been computed, and a formula for the
    exact solution is known.

    This function estimates the little l1 norm of the error:
      L1_NORM = sum ( 1 <= I <= N ) abs ( U(i) - EXACT(X(i)) )

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, int N, the number of nodes.

    Input, double X[N], the mesh points.

    Input, double U[N], the finite element coefficients.

    Input, function EQ = EXACT ( X ), returns the value of the exact
    solution at the point X.

    Output, double L1_ERROR, the little l1 norm of the error.
*/
{
  int i;
  double e1;

  e1 = 0.0;

  for ( i = 0; i < n; i++ )
  {
    e1 = e1 + fabs ( u[i] - exact ( x[i] ) );
  }
  e1 = e1 / ( double ) n;

  return e1;
}
/******************************************************************************/

double l2_error_linear ( int n, double x[], double u[], 
  double exact ( double x ) )

/******************************************************************************/
/*
  Purpose:

    L2_ERROR_LINEAR estimates the L2 error norm of a finite element solution.

  Discussion:

    We assume the finite element method has been used, over an interval [A,B]
    involving N nodes, with piecewise linear elements used for the basis.

    The coefficients U(1:N) have been computed, and a formula for the
    exact solution is known.

    This function estimates the L2 norm of the error:

      L2_NORM = Integral ( A <= X <= B ) ( U(X) - EXACT(X) )^2 dX

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    18 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, int N, the number of nodes.

    Input, double X[N], the mesh points.

    Input, double U[N], the finite element coefficients.

    Input, function EQ = EXACT ( X ), returns the value of the exact
    solution at the point X.

    Output, double L2_ERROR_LINEAR, the estimated L2 norm of the error.
*/
{
# define QUAD_NUM 2

  double abscissa[QUAD_NUM] = {
    -0.577350269189625764509148780502,
    +0.577350269189625764509148780502 };
  double e2;
  double eq;
  int i;
  int q;
  int quad_num = QUAD_NUM;
  double ul;
  double ur;
  double uq;
  double weight[QUAD_NUM] = { 1.0, 1.0 };
  double wq;
  double xl;
  double xq;
  double xr;

  e2 = 0.0;
/*
  Integrate over each interval.
*/
  for ( i = 0; i < n - 1; i++ )
  {
    xl = x[i];
    xr = x[i+1];
    ul = u[i];
    ur = u[i+1];

    for ( q = 0; q < quad_num; q++ )
    {
      xq = ( ( 1.0 - abscissa[q] ) * xl   
           + ( 1.0 + abscissa[q] ) * xr ) 
           /   2.0;

      wq = weight[q] * ( xr - xl ) / 2.0;
/*
  Use the fact that U is a linear combination of piecewise linears.
*/
      uq = ( ( xr - xq      ) * ul 
           + (      xq - xl ) * ur ) 
           / ( xr      - xl );

      eq = exact ( xq );

      e2 = e2 + wq * pow ( uq - eq, 2 );
    }
  }
  e2 = sqrt ( e2 );

  return e2;
# undef QUAD_NUM
}
/******************************************************************************/

double max_error_linear ( int n, double x[], double u[], 
  double exact ( double x ) )

/******************************************************************************/
/*
  Purpose:

    MAX_ERROR_LINEAR estimates the max error norm of a finite element solution.

  Discussion:

    We assume the finite element method has been used, over an interval [A,B]
    involving N nodes, with piecewise linear elements used for the basis.

    The coefficients U(1:N) have been computed, and a formula for the
    exact solution is known.

    This function estimates the max norm of the error:

      MAX_NORM = Integral ( A <= X <= B ) max ( abs ( U(X) - EXACT(X) ) ) dX

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    08 July 2015

  Author:

    John Burkardt

  Parameters:

    Input, int N, the number of nodes.

    Input, double X[N], the mesh points.

    Input, double U[N], the finite element coefficients.

    Input, function EQ = EXACT ( X ), returns the value of the exact
    solution at the point X.

    Output, double MAX_ERROR_LINEAR, the estimated max norm of the error.
*/
{
  int e;
  int e_num;
  double eq;
  int l;
  int q;
  int quad_num = 8;
  int r;
  double ul;
  double ur;
  double uq;
  double value;
  double xl;
  double xq;
  double xr;

  value = 0.0;
/*
  Integrate over each interval.
*/
  e_num = n - 1;

  for ( e = 0; e < e_num; e++ )
  {
    l = e;
    xl = x[l];
    ul = u[l];

    r = e + 1;
    xr = x[r];
    ur = u[r];

    for ( q = 0; q < quad_num; q++ )
    {
      xq = ( ( double ) ( quad_num - q ) * xl   
           + ( double ) (            q ) * xr ) 
           / ( double ) ( quad_num );
/*
  Use the fact that U is a linear combination of piecewise linears.
*/
      uq = ( ( xr - xq      ) * ul 
           + (      xq - xl ) * ur ) 
           / ( xr      - xl );

      eq = exact ( xq );

      value = r8_max ( value, fabs ( uq - eq ) );
    }
  }
/*
  For completeness, check last node.
*/
  xq = x[n-1];
  uq = u[n-1];
  eq = exact ( xq );
  value = r8_max ( value, fabs ( uq - eq ) );
/*
  Integral approximation requires multiplication by interval length.
*/
  value = value * ( x[n-1] - x[0] );

  return value;
}
/******************************************************************************/

double r8_max ( double x, double y )

/******************************************************************************/
/*
  Purpose:

    R8_MAX returns the maximum of two R8's.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    07 May 2006

  Author:

    John Burkardt

  Parameters:

    Input, double X, Y, the quantities to compare.

    Output, double R8_MAX, the maximum of X and Y.
*/
{
  double value;

  if ( y < x )
  {
    value = x;
  }
  else
  {
    value = y;
  }
  return value;
}
/******************************************************************************/

double *r8mat_solve2 ( int n, double a[], double b[], int *ierror )

/******************************************************************************/
/*
  Purpose:

    R8MAT_SOLVE2 computes the solution of an N by N linear system.

  Discussion: 							    

    An R8MAT is a doubly dimensioned array of R8 values, stored as a vector 
    in column-major order.

    The linear system may be represented as

      A*X = B

    If the linear system is singular, but consistent, then the routine will
    still produce a solution.

  Licensing:

    This code is distributed under the GNU LGPL license. 

  Modified:

    20 August 2010

  Author:

    John Burkardt

  Parameters:

    Input, int N, the number of equations.

    Input/output, double A[N*N].
    On input, A is the coefficient matrix to be inverted.
    On output, A has been overwritten.

    Input/output, double B[N].
    On input, B is the right hand side of the system.
    On output, B has been overwritten.

    Output, double R8MAT_SOLVE2[N], the solution of the linear system.

    Output, int *IERROR.
    0, no error detected.
    1, consistent singularity.
    2, inconsistent singularity.
*/
{
  double amax;
  int i;
  int imax;
  int j;
  int k;
  int *piv;
  double *x;

  *ierror = 0;

  piv = i4vec_zero_new ( n );
  x = r8vec_zero_new ( n );
/*
  Process the matrix.
*/
  for ( k = 1; k <= n; k++ )
  {
/*
  In column K:
    Seek the row IMAX with the properties that:
      IMAX has not already been used as a pivot;
      A(IMAX,K) is larger in magnitude than any other candidate.
*/
    amax = 0.0;
    imax = 0;
    for ( i = 1; i <= n; i++ )
    {
      if ( piv[i-1] == 0 )
      {
        if ( amax < fabs ( a[i-1+(k-1)*n] ) )
        {
          imax = i;
          amax = fabs ( a[i-1+(k-1)*n] );
        }
      }
    }
/*
  If you found a pivot row IMAX, then,
    eliminate the K-th entry in all rows that have not been used for pivoting.
*/
    if ( imax != 0 )
    {
      piv[imax-1] = k;
      for ( j = k+1; j <= n; j++ )
      {
        a[imax-1+(j-1)*n] = a[imax-1+(j-1)*n] / a[imax-1+(k-1)*n];
      }
      b[imax-1] = b[imax-1] / a[imax-1+(k-1)*n];
      a[imax-1+(k-1)*n] = 1.0;

      for ( i = 1; i <= n; i++ )
      {
        if ( piv[i-1] == 0 )
        {
          for ( j = k+1; j <= n; j++ )
          {
            a[i-1+(j-1)*n] = a[i-1+(j-1)*n] - a[i-1+(k-1)*n] * a[imax-1+(j-1)*n];
          }
          b[i-1] = b[i-1] - a[i-1+(k-1)*n] * b[imax-1];
          a[i-1+(k-1)*n] = 0.0;
        }
      }
    }
  }
/*
  Now, every row with nonzero PIV begins with a 1, and
  all other rows are all zero.  Begin solution.
*/
  for ( j = n; 1 <= j; j-- )
  {
    imax = 0;
    for ( k = 1; k <= n; k++ )
    {
      if ( piv[k-1] == j )
      {
        imax = k;
      }
    }

    if ( imax == 0 )
    {
      x[j-1] = 0.0;

      if ( b[j-1] == 0.0 )
      {
        *ierror = 1;
        printf ( "\n" );
        printf ( "R8MAT_SOLVE2 - Warning:\n" );
        printf ( "  Consistent singularity, equation = %d\n", j );
      }
      else
      {
        *ierror = 2;
        printf ( "\n" );
        printf ( "R8MAT_SOLVE2 - Warning:\n" );
        printf ( "  Inconsistent singularity, equation = %d\n", j );
      }
    }
    else
    {
      x[j-1] = b[imax-1];

      for ( i = 1; i <= n; i++ )
      {
        if ( i != imax )
        {
          b[i-1] = b[i-1] - a[i-1+(j-1)*n] * x[j-1];
        }
      }
    }
  }

  free ( piv );

  return x;
}
/******************************************************************************/

double *r8mat_zero_new ( int m, int n )

/******************************************************************************/
/*
  Purpose:

    R8MAT_ZERO_NEW returns a new zeroed R8MAT.

  Licensing:

    This code is distributed under the GNU LGPL license. 

  Modified:

    26 September 2008

  Author:

    John Burkardt

  Parameters:

    Input, int M, N, the number of rows and columns.

    Output, double R8MAT_ZERO[M*N], the new zeroed matrix.
*/
{
  double *a;
  int i;
  int j;

  a = ( double * ) malloc ( m * n * sizeof ( double ) );

  for ( j = 0; j < n; j++ )
  {
    for ( i = 0; i < m; i++ )
    {
      a[i+j*m] = 0.0;
    }
  }
  return a;
}
/******************************************************************************/

double *r8vec_linspace_new ( int n, double a, double b )

/******************************************************************************/
/*
  Purpose:

    R8VEC_LINSPACE_NEW creates a vector of linearly spaced values.

  Discussion:

    An R8VEC is a vector of R8's.

    4 points evenly spaced between 0 and 12 will yield 0, 4, 8, 12.
 
    In other words, the interval is divided into N-1 even subintervals,
    and the endpoints of intervals are used as the points.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    29 March 2011

  Author:

    John Burkardt

  Parameters:

    Input, int N, the number of entries in the vector.

    Input, double A, B, the first and last entries.

    Output, double R8VEC_LINSPACE_NEW[N], a vector of linearly spaced data.
*/
{
  int i;
  double *x;

  x = ( double * ) malloc ( n * sizeof ( double ) );

  if ( n == 1 )
  {
    x[0] = ( a + b ) / 2.0;
  }
  else
  {
    for ( i = 0; i < n; i++ )
    {
      x[i] = ( ( double ) ( n - 1 - i ) * a 
             + ( double ) (         i ) * b ) 
             / ( double ) ( n - 1     );
    }
  }
  return x;
}
/******************************************************************************/

double *r8vec_zero_new ( int n )

/******************************************************************************/
/*
  Purpose:

    R8VEC_ZERO_NEW creates and zeroes an R8VEC.

  Discussion:

    An R8VEC is a vector of R8's.

  Licensing:

    This code is distributed under the GNU LGPL license. 

  Modified:

    25 March 2009

  Author:

    John Burkardt

  Parameters:

    Input, int N, the number of entries in the vector.

    Output, double R8VEC_ZERO_NEW[N], a vector of zeroes.
*/
{
  double *a;
  int i;

  a = ( double * ) malloc ( n * sizeof ( double ) );

  for ( i = 0; i < n; i++ )
  {
    a[i] = 0.0;
  }
  return a;
}
/******************************************************************************/

void timestamp ( void )

/******************************************************************************/
/*
  Purpose:

    TIMESTAMP prints the current YMDHMS date as a time stamp.

  Example:

    31 May 2001 09:45:54 AM

  Licensing:

    This code is distributed under the GNU LGPL license. 

  Modified:

    24 September 2003

  Author:

    John Burkardt

  Parameters:

    None
*/
{
# define TIME_SIZE 40

  static char time_buffer[TIME_SIZE];
  const struct tm *tm;
  time_t now;

  now = time ( NULL );
  tm = localtime ( &now );

  strftime ( time_buffer, TIME_SIZE, "%d %B %Y %I:%M:%S %p", tm );

  fprintf ( stdout, "%s\n", time_buffer );

  return;
# undef TIME_SIZE
}
  

void test00 ( );
double a00 ( double x );
double c00 ( double x );
double exact00 ( double x );
double exact_ux00 ( double x );
double f00 ( double x );

void test01 ( );
double a1 ( double x );
double c1 ( double x );
double exact1 ( double x );
double exact_ux1 ( double x );
double f1 ( double x );

void test02 ( );
double a2 ( double x );
double c2 ( double x );
double exact2 ( double x );
double exact_ux2 ( double x );
double f2 ( double x );

void test03 ( );
double a3 ( double x );
double c3 ( double x );
double exact3 ( double x );
double exact_ux3 ( double x );
double f3 ( double x );

void test04 ( );
double a4 ( double x );
double c4 ( double x );
double exact4 ( double x );
double exact_ux4 ( double x );
double f4 ( double x );

void test05 ( );
double a5 ( double x );
double c5 ( double x );
double exact5 ( double x );
double exact_ux5 ( double x );
double f5 ( double x );

void test06 ( );
double a6 ( double x );
double c6 ( double x );
double exact6 ( double x );
double exact_ux6 ( double x );
double f6 ( double x );

void test07 ( );
double a7 ( double x );
double c7 ( double x );
double exact7 ( double x );
double exact_ux7 ( double x );
double f7 ( double x );

void test08 ( );
double a8 ( double x );
double c8 ( double x );
double exact8 ( double x );
double exact_ux8 ( double x );
double f8 ( double x );

void test09 ( );
double a9 ( double x );
double c9 ( double x );
double exact9 ( double x );
double exact_ux9 ( double x );
double f9 ( double x );

void test10 ( );
double a10 ( double x );
double c10 ( double x );
double exact10 ( double x );
double exact_ux10 ( double x );
double f10 ( double x );

/******************************************************************************/

int main ( )

/******************************************************************************/
/*
  Purpose:

    MAIN is the main program for FEM1D_BVP_LINEAR_TEST.

  Location:

    http://people.sc.fsu.edu/~jburkardt/c_src/fem1d_bvp_linear/fem1d_bvp_linear_prb.c

  Discussion:

    FEM1D_BVP_LINEAR_TEST tests the FEM1D_BVP_LINEAR library.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    18 July 2015

  Author:

    John Burkardt
*/
{
  timestamp ( );
  printf ( "\n" );
  printf ( "FEM1D_BVP_LINEAR_TEST\n" );
  printf ( "  C version\n" );
  printf ( "  Test the FEM1D_BVP_LINEAR library.\n" );

  test00 ( );
  test01 ( );
  test02 ( );
  test03 ( );
  test04 ( );
  test05 ( );
  test06 ( );
  test07 ( );
  test08 ( );
  test09 ( );
  test10 ( );
/*
  Terminate.
*/
  printf ( "\n" );
  printf ( "FEM1D_BVP_LINEAR_TEST\n" );
  printf ( "  Normal end of execution.\n" );
  printf ( "\n" );
  timestamp ( );

  return 0;
}
/******************************************************************************/

void test00 ( )

/******************************************************************************/
/*
  Purpose:

    TEST00 carries out test case #0.

  Discussion:

    - uxx + u = x  for 0 < x < 1
    u(0) = u(1) = 0

    exact  = x - sinh(x) / sinh(1)
    exact' = 1 - cosh(x) / sinh(1)

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    10 July 2015

  Author:

    John Burkardt

  Reference:

    Dianne O'Leary,
    Scientific Computing with Case Studies,
    SIAM, 2008,
    ISBN13: 978-0-898716-66-5,
    LC: QA401.O44.
*/
{
  int i;
  int n = 11;
  double e1;
  double e2;
  double h1s;
  double mx;
  double *u;
  double uexact;
  double *x;
  double x_first;
  double x_last;

  printf ( "\n" );
  printf ( "TEST00\n" );
  printf ( "  Solve -( A(x) U'(x) )' + C(x) U(x) = F(x)\n" );
  printf ( "  for 0 < x < 1, with U(0) = U(1) = 0.\n" );
  printf ( "  A(X)  = 1.0\n" );
  printf ( "  C(X)  = 1.0\n" );
  printf ( "  F(X)  = X\n" );
  printf ( "  U(X)  = X - SINH(X) / SINH(1)\n" );
  printf ( "\n" );
  printf ( "  Number of nodes = %d\n", n );
/*
  Geometry definitions.
*/
  x_first = 0.0;
  x_last = 1.0;
  x = r8vec_linspace_new ( n, x_first, x_last );

  u = fem1d_bvp_linear ( n, a00, c00, f00, x );

  printf ( "\n" );
  printf ( "     I    X         U         Uexact    Error\n" );
  printf ( "\n" );

  for ( i = 0; i < n; i++ )
  {
    uexact = exact00 ( x[i] );
    printf ( "  %4d  %8f  %14f  %14f %14e\n", 
      i, x[i], u[i], uexact, fabs ( u[i] - uexact ) );
  }

  e1 = l1_error ( n, x, u, exact00 );
  e2 = l2_error_linear ( n, x, u, exact00 );
  h1s = h1s_error_linear ( n, x, u, exact_ux00 );
  mx = max_error_linear ( n, x, u, exact00 );
  printf ( "\n" );
  printf ( "  l1 norm of error  = %g\n", e1 );
  printf ( "  L2 norm of error  = %g\n", e2 );
  printf ( "  Seminorm of error = %g\n", h1s );
  printf ( "  Max norm of error = %g\n", mx );

  free ( u );
  free ( x );

  return;
}
/******************************************************************************/

double a00 ( double x )

/******************************************************************************/
/*
  Purpose:

    A00 evaluates A function #0.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    10 July 2015

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double A00, the value of A(X).
*/
{
  double value;

  value = 1.0;

  return value;
}
/******************************************************************************/

double c00 ( double x )

/******************************************************************************/
/*
  Purpose:

    C00 evaluates C function #0.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    10 July 2015

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double C00, the value of C(X).
*/
{
  double value;

  value = 1.0;

  return value;
}
/******************************************************************************/

double exact00 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT00 evaluates exact solution #0.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    10 July 2015

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT00, the value of U(X).
*/
{
  double value;

  value = x - sinh ( x ) / sinh ( 1.0 );

  return value;
}
/******************************************************************************/

double exact_ux00 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT_UX00 evaluates the derivative of exact solution #0.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    10 July 2015

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT_UX00, the value of dUdX(X).
*/
{
  double value;

  value = 1.0 - cosh ( x ) / sinh ( 1.0 );

  return value;
}
/******************************************************************************/

double f00 ( double x )

/******************************************************************************/
/*
  Purpose:

    F00 evaluates right hand side function #0.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    10 July 2015

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double F00, the value of F(X).
*/
{
  double value;

  value = x;

  return value;
}
/******************************************************************************/

void test01 ( )

/******************************************************************************/
/*
  Purpose:

    TEST01 carries out test case #1.

  Discussion:

    Use A1, C1, F1, EXACT1, EXACT_UX1.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Reference:

    Dianne O'Leary,
    Scientific Computing with Case Studies,
    SIAM, 2008,
    ISBN13: 978-0-898716-66-5,
    LC: QA401.O44.
*/
{
  int i;
  int n = 11;
  double e1;
  double e2;
  double h1s;
  double mx;
  double *u;
  double uexact;
  double *x;
  double x_first;
  double x_last;

  printf ( "\n" );
  printf ( "TEST01\n" );
  printf ( "  Solve -( A(x) U'(x) )' + C(x) U(x) = F(x)\n" );
  printf ( "  for 0 < x < 1, with U(0) = U(1) = 0.\n" );
  printf ( "  A1(X)  = 1.0\n" );
  printf ( "  C1(X)  = 0.0\n" );
  printf ( "  F1(X)  = X * ( X + 3 ) * exp ( X )\n" );
  printf ( "  U1(X)  = X * ( 1 - X ) * exp ( X )\n" );
  printf ( "\n" );
  printf ( "  Number of nodes = %d\n", n );
/*
  Geometry definitions.
*/
  x_first = 0.0;
  x_last = 1.0;
  x = r8vec_linspace_new ( n, x_first, x_last );

  u = fem1d_bvp_linear ( n, a1, c1, f1, x );

  printf ( "\n" );
  printf ( "     I    X         U         Uexact    Error\n" );
  printf ( "\n" );

  for ( i = 0; i < n; i++ )
  {
    uexact = exact1 ( x[i] );
    printf ( "  %4d  %8f  %14f  %14f %14e\n", 
      i, x[i], u[i], uexact, fabs ( u[i] - uexact ) );
  }

  e1 = l1_error ( n, x, u, exact1 );
  e2 = l2_error_linear ( n, x, u, exact1 );
  h1s = h1s_error_linear ( n, x, u, exact_ux1 );
  mx = max_error_linear ( n, x, u, exact1 );
  printf ( "\n" );
  printf ( "  l1 norm of error  = %g\n", e1 );
  printf ( "  L2 norm of error  = %g\n", e2 );
  printf ( "  Seminorm of error = %g\n", h1s );
  printf ( "  Max norm of error = %g\n", mx );

  free ( u );
  free ( x );

  return;
}
/******************************************************************************/

double a1 ( double x )

/******************************************************************************/
/*
  Purpose:

    A1 evaluates A function #1.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    20 August 2010

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double A1, the value of A(X).
*/
{
  double value;

  value = 1.0;

  return value;
}
/******************************************************************************/

double c1 ( double x )

/******************************************************************************/
/*
  Purpose:

    C1 evaluates C function #1.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    20 August 2010

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double C1, the value of C(X).
*/
{
  double value;

  value = 0.0;

  return value;
}
/******************************************************************************/

double exact1 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT1 evaluates exact solution #1.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT1, the value of U(X).
*/
{
  double value;

  value = x * ( 1.0 - x ) * exp ( x );

  return value;
}
/******************************************************************************/

double exact_ux1 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT_UX1 evaluates the derivative of exact solution #1.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT_UX1, the value of dUdX(X).
*/
{
  double value;

  value = ( 1.0 - x - x * x ) * exp ( x );

  return value;
}
/******************************************************************************/

double f1 ( double x )

/******************************************************************************/
/*
  Purpose:

    F1 evaluates right hand side function #1.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    20 August 2010

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double F1, the value of F(X).
*/
{
  double value;

  value = x * ( x + 3.0 ) * exp ( x );

  return value;
}
/******************************************************************************/

void test02 ( )

/******************************************************************************/
/*
  Purpose:

    TEST02 carries out test case #2.

  Discussion:

    Use A2, C2, F2, EXACT2, EXACT_UX2.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Reference:

    Dianne O'Leary,
    Scientific Computing with Case Studies,
    SIAM, 2008,
    ISBN13: 978-0-898716-66-5,
    LC: QA401.O44.
*/
{
  int i;
  int n = 11;
  double e1;
  double e2;
  double h1s;
  double mx;
  double *u;
  double uexact;
  double *x;
  double x_first;
  double x_last;

  printf ( "\n" );
  printf ( "TEST02\n" );
  printf ( "  Solve -( A(x) U'(x) )' + C(x) U(x) = F(x)\n" );
  printf ( "  for 0 < x < 1, with U(0) = U(1) = 0.\n" );
  printf ( "  A2(X)  = 1.0\n" );
  printf ( "  C2(X)  = 2.0\n" );
  printf ( "  F2(X)  = X * ( 5 - X ) * exp ( X )\n" );
  printf ( "  U2(X)  = X * ( 1 - X ) * exp ( X )\n" );
  printf ( "\n" );
  printf ( "  Number of nodes = %d\n", n );
/*
  Geometry definitions.
*/
  x_first = 0.0;
  x_last = 1.0;
  x = r8vec_linspace_new ( n, x_first, x_last );

  u = fem1d_bvp_linear ( n, a2, c2, f2, x );

  printf ( "\n" );
  printf ( "     I    X         U         Uexact    Error\n" );
  printf ( "\n" );

  for ( i = 0; i < n; i++ )
  {
    uexact = exact2 ( x[i] );
    printf ( "  %4d  %8f  %14f  %14f %14e\n", 
      i, x[i], u[i], uexact, fabs ( u[i] - uexact ) );
  }

  e1 = l1_error ( n, x, u, exact2 );
  e2 = l2_error_linear ( n, x, u, exact2 );
  h1s = h1s_error_linear ( n, x, u, exact_ux2 );
  mx = max_error_linear ( n, x, u, exact2 );
  printf ( "\n" );
  printf ( "  l1 norm of error  = %g\n", e1 );
  printf ( "  L2 norm of error  = %g\n", e2 );
  printf ( "  Seminorm of error = %g\n", h1s );
  printf ( "  Max norm of error = %g\n", mx );

  free ( u );
  free ( x );

  return;
}
/******************************************************************************/

double a2 ( double x )

/******************************************************************************/
/*
  Purpose:

    A2 evaluates A function #2.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double A2, the value of A(X).
*/
{
  double value;

  value = 1.0;

  return value;
}
/******************************************************************************/

double c2 ( double x )

/******************************************************************************/
/*
  Purpose:

    C2 evaluates C function #2.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    20 August 2010

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double C2, the value of C(X).
*/
{
  double value;

  value = 2.0;

  return value;
}
/******************************************************************************/

double exact2 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT2 evaluates exact solution #2.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT2, the value of U(X).
*/
{
  double value;

  value = x * ( 1.0 - x ) * exp ( x );

  return value;
}
/******************************************************************************/

double exact_ux2 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT_UX2 evaluates the derivative of exact solution #2.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT_UX2, the value of dUdX(X).
*/
{
  double value;

  value = ( 1.0 - x - x * x ) * exp ( x );

  return value;
}
/******************************************************************************/

double f2 ( double x )

/******************************************************************************/
/*
  Purpose:

    F2 evaluates right hand side function #2.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    20 August 2010

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double F2, the value of F(X).
*/
{
  double value;

  value = x * ( 5.0 - x ) * exp ( x );

  return value;
}
/******************************************************************************/

void test03 ( )

/******************************************************************************/
/*
  Purpose:

    TEST03 carries out test case #3.

  Discussion:

    Use A3, C3, F3, EXACT3, EXACT_UX3.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Reference:

    Dianne O'Leary,
    Scientific Computing with Case Studies,
    SIAM, 2008,
    ISBN13: 978-0-898716-66-5,
    LC: QA401.O44.
*/
{
  int i;
  int n = 11;
  double e1;
  double e2;
  double h1s;
  double mx;
  double *u;
  double uexact;
  double *x;
  double x_first;
  double x_last;

  printf ( "\n" );
  printf ( "TEST03\n" );
  printf ( "  Solve -( A(x) U'(x) )' + C(x) U(x) = F(x)\n" );
  printf ( "  for 0 < x < 1, with U(0) = U(1) = 0.\n" );
  printf ( "  A3(X)  = 1.0\n" );
  printf ( "  C3(X)  = 2.0 * X\n" );
  printf ( "  F3(X)  = - X * ( 2 * X * X - 3 * X - 3 ) * exp ( X )\n" );
  printf ( "  U3(X)  = X * ( 1 - X ) * exp ( X )\n" );
  printf ( "\n" );
  printf ( "  Number of nodes = %d\n", n );
/*
  Geometry definitions.
*/
  x_first = 0.0;
  x_last = 1.0;
  x = r8vec_linspace_new ( n, x_first, x_last );

  u = fem1d_bvp_linear ( n, a3, c3, f3, x );

  printf ( "\n" );
  printf ( "     I    X         U         Uexact    Error\n" );
  printf ( "\n" );

  for ( i = 0; i < n; i++ )
  {
    uexact = exact3 ( x[i] );
    printf ( "  %4d  %8f  %14f  %14f %14e\n", 
      i, x[i], u[i], uexact, fabs ( u[i] - uexact ) );
  }

  e1 = l1_error ( n, x, u, exact3 );
  e2 = l2_error_linear ( n, x, u, exact3 );
  h1s = h1s_error_linear ( n, x, u, exact_ux3 );
  mx = max_error_linear ( n, x, u, exact3 );
  printf ( "\n" );
  printf ( "  l1 norm of error  = %g\n", e1 );
  printf ( "  L2 norm of error  = %g\n", e2 );
  printf ( "  Seminorm of error = %g\n", h1s );
  printf ( "  Max norm of error = %g\n", mx );

  free ( u );
  free ( x );

  return;
}
/******************************************************************************/

double a3 ( double x )

/******************************************************************************/
/*
  Purpose:

    A3 evaluates A function #3.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double A3, the value of A(X).
*/
{
  double value;

  value = 1.0;

  return value;
}
/******************************************************************************/

double c3 ( double x )

/******************************************************************************/
/*
  Purpose:

    C3 evaluates C function #3.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    20 August 2010

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double C3, the value of C(X).
*/
{
  double value;

  value = 2.0 * x;

  return value;
}
/******************************************************************************/

double exact3 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT3 evaluates exact solution #3.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT3, the value of U(X).
*/
{
  double value;

  value = x * ( 1.0 - x ) * exp ( x );

  return value;
}
/******************************************************************************/

double exact_ux3 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT_UX3 evaluates the derivative of exact solution #3.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT_UX3, the value of dUdX(X).
*/
{
  double value;

  value = ( 1.0 - x - x * x ) * exp ( x );

  return value;
}
/******************************************************************************/

double f3 ( double x )

/******************************************************************************/
/*
  Purpose:

    F3 evaluates right hand side function #3.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    20 August 2010

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double F3, the value of F(X).
*/
{
  double value;

  value = - x * ( 2.0 * x * x - 3.0 * x - 3.0 ) * exp ( x );

  return value;
}
/******************************************************************************/

void test04 ( )

/******************************************************************************/
/*
  Purpose:

    TEST04 carries out test case #4.

  Discussion:

    Use A4, C4, F4, EXACT4, EXACT_UX4.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Reference:

    Dianne O'Leary,
    Scientific Computing with Case Studies,
    SIAM, 2008,
    ISBN13: 978-0-898716-66-5,
    LC: QA401.O44.
*/
{
  int i;
  int n = 11;
  double e1;
  double e2;
  double h1s;
  double mx;
  double *u;
  double uexact;
  double *x;
  double x_first;
  double x_last;

  printf ( "\n" );
  printf ( "TEST04\n" );
  printf ( "  Solve -( A(x) U'(x) )' + C(x) U(x) = F(x)\n" );
  printf ( "  for 0 < x < 1, with U(0) = U(1) = 0.\n" );
  printf ( "  A4(X)  = 1.0 + X * X\n" );
  printf ( "  C4(X)  = 0.0\n" );
  printf ( "  F4(X)  = ( X + 3 X^2 + 5 X^3 + X^4 ) * exp ( X )\n" );
  printf ( "  U4(X)  = X * ( 1 - X ) * exp ( X )\n" );
  printf ( "\n" );
  printf ( "  Number of nodes = %d\n", n );
/*
  Geometry definitions.
*/
  x_first = 0.0;
  x_last = 1.0;
  x = r8vec_linspace_new ( n, x_first, x_last );

  u = fem1d_bvp_linear ( n, a4, c4, f4, x );

  printf ( "\n" );
  printf ( "     I    X         U         Uexact    Error\n" );
  printf ( "\n" );

  for ( i = 0; i < n; i++ )
  {
    uexact = exact4 ( x[i] );
    printf ( "  %4d  %8f  %14f  %14f %14e\n", 
      i, x[i], u[i], uexact, fabs ( u[i] - uexact ) );
  }

  e1 = l1_error ( n, x, u, exact4 );
  e2 = l2_error_linear ( n, x, u, exact4 );
  h1s = h1s_error_linear ( n, x, u, exact_ux4 );
  mx = max_error_linear ( n, x, u, exact4 );
  printf ( "\n" );
  printf ( "  l1 norm of error  = %g\n", e1 );
  printf ( "  L2 norm of error  = %g\n", e2 );
  printf ( "  Seminorm of error = %g\n", h1s );
  printf ( "  Max norm of error = %g\n", mx );

  free ( u );
  free ( x );

  return;
}
/******************************************************************************/

double a4 ( double x )

/******************************************************************************/
/*
  Purpose:

    A4 evaluates A function #4.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double A4, the value of A(X).
*/
{
  double value;

  value = 1.0 + x * x;

  return value;
}
/******************************************************************************/

double c4 ( double x )

/******************************************************************************/
/*
  Purpose:

    C4 evaluates C function #4.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double C4, the value of C(X).
*/
{
  double value;

  value = 0.0;

  return value;
}
/******************************************************************************/

double exact4 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT4 evaluates exact solution #4.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT4, the value of U(X).
*/
{
  double value;

  value = x * ( 1.0 - x ) * exp ( x );

  return value;
}
/******************************************************************************/

double exact_ux4 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT_UX4 evaluates the derivative of exact solution #4.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT_UX4, the value of dUdX(X).
*/
{
  double value;

  value = ( 1.0 - x - x * x ) * exp ( x );

  return value;
}
/******************************************************************************/

double f4 ( double x )

/******************************************************************************/
/*
  Purpose:

    F4 evaluates right hand side function #4.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    20 August 2010

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double F4, the value of F(X).
*/
{
  double value;

  value = ( x + 3.0 * x * x + 5.0 * x * x * x + x * x * x * x ) * exp ( x );

  return value;
}
/******************************************************************************/

void test05 ( )

/******************************************************************************/
/*
  Purpose:

    TEST05 carries out test case #5.

  Discussion:

    Use A5, C5, F5, EXACT5, EXACT_UX5.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Reference:

    Dianne O'Leary,
    Scientific Computing with Case Studies,
    SIAM, 2008,
    ISBN13: 978-0-898716-66-5,
    LC: QA401.O44.
*/
{
  int i;
  int n = 11;
  double e1;
  double e2;
  double h1s;
  double mx;
  double *u;
  double uexact;
  double *x;
  double x_first;
  double x_last;

  printf ( "\n" );
  printf ( "TEST05\n" );
  printf ( "  Solve -( A(x) U'(x) )' + C(x) U(x) = F(x)\n" );
  printf ( "  for 0 < x < 1, with U(0) = U(1) = 0.\n" );
  printf ( "  A5(X)  = 1.0 + X * X for X <= 1/3\n" );
  printf ( "         = 7/9 + X     for      1/3 < X\n" );
  printf ( "  C5(X)  = 0.0\n" );
  printf ( "  F5(X)  = ( X + 3 X^2 + 5 X^3 + X^4 ) * exp ( X )\n" );
  printf ( "                       for X <= 1/3\n" );
  printf ( "         = ( - 1 + 10/3 X + 43/9 X^2 + X^3 ) .* exp ( X )\n" );
  printf ( "                       for      1/3 <= X\n" );
  printf ( "  U5(X)  = X * ( 1 - X ) * exp ( X )\n" );
  printf ( "\n" );
  printf ( "  Number of nodes = %d\n", n );
/*
  Geometry definitions.
*/
  x_first = 0.0;
  x_last = 1.0;
  x = r8vec_linspace_new ( n, x_first, x_last );

  u = fem1d_bvp_linear ( n, a5, c5, f5, x );

  printf ( "\n" );
  printf ( "     I    X         U         Uexact    Error\n" );
  printf ( "\n" );

  for ( i = 0; i < n; i++ )
  {
    uexact = exact5 ( x[i] );
    printf ( "  %4d  %8f  %14f  %14f %14e\n", 
      i, x[i], u[i], uexact, fabs ( u[i] - uexact ) );
  }

  e1 = l1_error ( n, x, u, exact5 );
  e2 = l2_error_linear ( n, x, u, exact5 );
  h1s = h1s_error_linear ( n, x, u, exact_ux5 );
  mx = max_error_linear ( n, x, u, exact5 );
  printf ( "\n" );
  printf ( "  l1 norm of error  = %g\n", e1 );
  printf ( "  L2 norm of error  = %g\n", e2 );
  printf ( "  Seminorm of error = %g\n", h1s );
  printf ( "  Max norm of error = %g\n", mx );

  free ( u );
  free ( x );

  return;
}
/******************************************************************************/

double a5 ( double x )

/******************************************************************************/
/*
  Purpose:

    A5 evaluates A function #5.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double A5, the value of A(X).
*/
{
  double value;

  if ( x <= 1.0 / 3.0 )
  {
    value = 1.0 + x * x;
  }
  else
  {
    value = x + 7.0 / 9.0;
  }

  return value;
}
/******************************************************************************/

double c5 ( double x )

/******************************************************************************/
/*
  Purpose:

    C5 evaluates C function #5.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double C5, the value of C(X).
*/
{
  double value;

  value = 0.0;

  return value;
}
/******************************************************************************/

double exact5 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT5 evaluates exact solution #5.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT5, the value of U(X).
*/
{
  double value;

  value = x * ( 1.0 - x ) * exp ( x );

  return value;
}
/******************************************************************************/

double exact_ux5 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT_UX5 evaluates the derivative of exact solution #5.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT_UX5, the value of dUdX(X).
*/
{
  double value;

  value = ( 1.0 - x - x * x ) * exp ( x );

  return value;
}
/******************************************************************************/

double f5 ( double x )

/******************************************************************************/
/*
  Purpose:

    F5 evaluates right hand side function #5.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    20 August 2010

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double F5, the value of F(X).
*/
{
  double value;

  if ( x <= 1.0 / 3.0 )
  {
    value = ( x + 3.0 * x * x + 5.0 * x * x * x + x * x * x * x ) * exp ( x );
  }
  else
  {
    value = ( - 1.0 + ( 10.0 / 3.0 ) * x 
      + ( 43.0 / 9.0 ) * x * x + x * x * x ) * exp ( x );
  }

  return value;
}
/******************************************************************************/

void test06 ( )

/******************************************************************************/
/*
  Purpose:

    TEST06 does an error analysis.

  Discussion:

    Use A6, C6, F6, EXACT6, EXACT_UX6.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt
*/
{
  int i;
  int n;
  double e1;
  double e2;
  double h1s;
  double mx;
  double *u;
  double *x;
  double x_first;
  double x_last;

  printf ( "\n" );
  printf ( "TEST06\n" );
  printf ( "  Solve -( A(x) U'(x) )' + C(x) U(x) = F(x)\n" );
  printf ( "  for 0 < x < 1, with U(0) = U(1) = 0.\n" );
  printf ( "  A6(X)  = 1.0\n" );
  printf ( "  C6(X)  = 0.0\n" );
  printf ( "  F6(X)  = pi*pi*sin(pi*X)\n" );
  printf ( "  U6(X)  = sin(pi*x)\n" );
  printf ( "\n" );
  printf ( "  Compute l1norm, L2norm and seminorm of error for various N.\n" );
  printf ( "\n" );
  printf ( "     N        l1 error       L2 error      Seminorm error  Maxnorm error\n" );
  printf ( "\n" );

  n = 11;
  for ( i = 0; i <= 4; i++ )
  {
/*
  Geometry definitions.
*/
    x_first = 0.0;
    x_last = 1.0;
    x = r8vec_linspace_new ( n, x_first, x_last );

    u = fem1d_bvp_linear ( n, a6, c6, f6, x );

    e1 = l1_error ( n, x, u, exact6 );
    e2 = l2_error_linear ( n, x, u, exact6 );
    h1s = h1s_error_linear ( n, x, u, exact_ux6 );
    mx = max_error_linear ( n, x, u, exact6 );

    printf ( "  %4d  %14g  %14g  %14g  %14g\n", 
      n, e1, e2, h1s, mx );

    n = 2 * ( n - 1 ) + 1;

    free ( u );
    free ( x );
  }

  return;
}
/******************************************************************************/

double a6 ( double x )

/******************************************************************************/
/*
  Purpose:

    A6 evaluates A function #6.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double A6, the value of A(X).
*/
{
  double value;

  value = 1.0;

  return value;
}
/******************************************************************************/

double c6 ( double x )

/******************************************************************************/
/*
  Purpose:

    C6 evaluates C function #6.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double C6, the value of C(X).
*/
{
  double value;

  value = 0.0;

  return value;
}
/******************************************************************************/

double exact6 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT6 returns exact solution #6.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT6, the value of U(X).
*/
{
  const double pi = 3.141592653589793;
  double value;

  value = sin ( pi * x );

  return value;
}
/******************************************************************************/

double exact_ux6 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT_UX6 returns the derivative of exact solution #6.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    14 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT_UX6, the value of U(X).
*/
{
  const double pi = 3.141592653589793;
  double value;

  value = pi * cos ( pi * x );

  return value;
}
/******************************************************************************/

double f6 ( double x )

/******************************************************************************/
/*
  Purpose:

    F6 evaluates right hand side function #6.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    19 February 2012

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double F6, the value of F(X).
*/
{
  static double pi = 3.141592653589793;
  double value;

  value = pi * pi * sin ( pi * x );

  return value;
}
/******************************************************************************/

void test07 ( )

/******************************************************************************/
/*
  Purpose:

    TEST07 does an error analysis.

  Discussion:

    Use A7, C7, F7, EXACT7, EXACT_UX7.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    09 June 2014

  Author:

    John Burkardt

  Reference:

    Eric Becker, Graham Carey, John Oden,
    Finite Elements, An Introduction, Volume I,
    Prentice-Hall, 1981, page 123-124,
    ISBN: 0133170578,
    LC: TA347.F5.B4.
*/
{
  int i;
  int n;
  double e1;
  double e2;
  double h1s;
  double mx;
  double *u;
  double *x;
  double x_first;
  double x_last;

  printf ( "\n" );
  printf ( "TEST07\n" );
  printf ( "  Solve -( A(x) U'(x) )' + C(x) U(x) = F(x)\n" );
  printf ( "  for 0 < x < 1, with U(0) = U(1) = 0.\n" );
  printf ( "  Becker/Carey/Oden Example\n" );
  printf ( "\n" );
  printf ( "  Compute l1 norm, L2 norm and seminorm of error for various N.\n" );
  printf ( "\n" );
  printf ( "     N        l1 error      L2 error      Seminorm error  Maxnorm error\n" );
  printf ( "\n" );

  n = 11;
  for ( i = 0; i <= 4; i++ )
  {
/*
  Geometry definitions.
*/
    x_first = 0.0;
    x_last = 1.0;
    x = r8vec_linspace_new ( n, x_first, x_last );

    u = fem1d_bvp_linear ( n, a7, c7, f7, x );

    e1 = l1_error ( n, x, u, exact7 );
    e2 = l2_error_linear ( n, x, u, exact7 );
    h1s = h1s_error_linear ( n, x, u, exact_ux7 );
    mx = max_error_linear ( n, x, u, exact7 );

    printf ( "  %4d  %14g  %14g  %14g  %14g\n", 
      n, e1, e2, h1s, mx );

    n = 2 * ( n - 1 ) + 1;

    free ( u );
    free ( x );
  }

  return;
}
/******************************************************************************/

double a7 ( double x )

/******************************************************************************/
/*
  Purpose:

    A7 evaluates A function #7.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    09 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double A7, the value of A(X).
*/
{
  double alpha;
  double value;
  double x0;

  alpha = 30.0;
  x0 = 1.0 / 3.0;
  value = 1.0 / alpha + alpha * pow ( x - x0, 2 );

  return value;
}
/******************************************************************************/

double c7 ( double x )

/******************************************************************************/
/*
  Purpose:

    C7 evaluates C function #7.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    09 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double C7, the value of C(X).
*/
{
  double value;

  value = 0.0;

  return value;
}
/******************************************************************************/

double exact7 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT7 returns exact solution #7.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    09 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT7, the value of U(X).
*/
{
  double alpha;
  double value;
  double x0;

  alpha = 30.0;
  x0 = 1.0 / 3.0;
  value = ( 1.0 - x ) 
    * ( atan ( alpha * ( x - x0 ) ) + atan ( alpha * x0 ) );

  return value;
}
/******************************************************************************/

double exact_ux7 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT_UX7 returns the derivative of exact solution #7.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    09 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT_UX7, the value of U(X).
*/
{
  double alpha;
  double value;
  double x0;

  alpha = 30.0;
  x0 = 1.0 / 3.0;
  value = - atan ( alpha * ( x - x0 ) ) - atan ( alpha * x0 ) 
    + ( 1.0 - x ) * alpha / ( 1.0 + alpha * alpha * pow ( x - x0, 2 ) );

  return value;
}
/******************************************************************************/

double f7 ( double x )

/******************************************************************************/
/*
  Purpose:

    F7 evaluates right hand side function #7.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    09 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double F7, the value of F(X).
*/
{
  double alpha;
  double value;
  double x0;

  alpha = 30.0;
  x0 = 1.0 / 3.0;
  value = 2.0 * ( 1.0 + alpha * ( x - x0 ) * 
    ( atan ( alpha * ( x - x0 ) ) + atan ( alpha * x0 ) ) );

  return value;
}
/******************************************************************************/

void test08 ( )

/******************************************************************************/
/*
  Purpose:

    TEST08 carries out test case #8.

  Discussion:

    Use A8, C8, F8, EXACT8, EXACT_UX8.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    16 June 2014

  Author:

    John Burkardt

  Reference:

    Dianne O'Leary,
    Scientific Computing with Case Studies,
    SIAM, 2008,
    ISBN13: 978-0-898716-66-5,
    LC: QA401.O44.
*/
{
  int i;
  int n = 11;
  double e1;
  double e2;
  double h1s;
  double mx;
  double *u;
  double uexact;
  double *x;
  double x_first;
  double x_last;

  printf ( "\n" );
  printf ( "TEST08\n" );
  printf ( "  Solve -( A(x) U'(x) )' + C(x) U(x) = F(x)\n" );
  printf ( "  for 0 < x < 1, with U(0) = U(1) = 0.\n" );
  printf ( "  A8(X) = 1.0\n" );
  printf ( "  C8(X) = 0.0\n" );
  printf ( "  F8(X) = X * ( X + 3 ) * exp ( X ),   X <= 2/3\n" );
  printf ( "        = 2 * exp ( 2/3),                   2/3 < X\n" );
  printf ( "  U8(X) = X * ( 1 - X ) * exp ( X ),   X <= 2/3\n" );
  printf ( "        = X * ( 1 - X ) * exp ( 2/3 ),      2/3 < X\n" );
  printf ( "\n" );
  printf ( "  Number of nodes = %d\n", n );
/*
  Geometry definitions.
*/
  x_first = 0.0;
  x_last = 1.0;
  x = r8vec_linspace_new ( n, x_first, x_last );

  u = fem1d_bvp_linear ( n, a8, c8, f8, x );

  printf ( "\n" );
  printf ( "     I    X         U         Uexact    Error\n" );
  printf ( "\n" );

  for ( i = 0; i < n; i++ )
  {
    uexact = exact8 ( x[i] );
    printf ( "  %4d  %8f  %14f  %14f %14e\n", 
      i, x[i], u[i], uexact, fabs ( u[i] - uexact ) );
  }

  e1 = l1_error ( n, x, u, exact8 );
  e2 = l2_error_linear ( n, x, u, exact8 );
  h1s = h1s_error_linear ( n, x, u, exact_ux8 );
  mx = max_error_linear ( n, x, u, exact8 );
  printf ( "\n" );
  printf ( "  l1 norm of error  = %g\n", e1 );
  printf ( "  L2 norm of error  = %g\n", e2 );
  printf ( "  Seminorm of error = %g\n", h1s );
  printf ( "  Max norm of error = %g\n", mx );

  free ( u );
  free ( x );

  return;
}
/******************************************************************************/

double a8 ( double x )

/******************************************************************************/
/*
  Purpose:

    A8 evaluates A function #8.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    16 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double A8, the value of A(X).
*/
{
  double value;

  value = 1.0;

  return value;
}
/******************************************************************************/

double c8 ( double x )

/******************************************************************************/
/*
  Purpose:

    C8 evaluates C function #8.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    16 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double C8, the value of C(X).
*/
{
  double value;

  value = 0.0;

  return value;
}
/******************************************************************************/

double exact8 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT8 evaluates exact solution #8.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    16 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT8, the value of U(X).
*/
{
  double value;

  if ( x <= 2.0 / 3.0 )
  {
    value = x * ( 1.0 - x ) * exp ( x );
  }
  else
  {
    value = x * ( 1.0 - x ) * exp ( 2.0 / 3.0 );
  }

  return value;
}
/******************************************************************************/

double exact_ux8 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT_UX8 evaluates the derivative of exact solution #8.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    16 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT_UX8, the value of dUdX(X).
*/
{
  double value;

  if ( x <= 2.0 / 3.0 )
  {
    value = ( 1.0 - x - x * x ) * exp ( x );
  }
  else
  {
    value = ( 1.0 - 2.0 * x ) * exp ( 2.0 / 3.0 );
  }

  return value;
}
/******************************************************************************/

double f8 ( double x )

/******************************************************************************/
/*
  Purpose:

    F8 evaluates right hand side function #8.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    16 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double F8, the value of F(X).
*/
{
  double value;

  if ( x <= 2.0 / 3.0 )
  {
    value = x * ( x + 3.0 ) * exp ( x );
  }
  else
  {
    value = 2.0 * exp ( 2.0 / 3.0 );
  }

  return value;
}
/******************************************************************************/

void test09 ( )

/******************************************************************************/
/*
  Purpose:

    TEST09 carries out test case #9.

  Discussion:

    Use A9, C9, F9, EXACT9, EXACT_UX9.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    16 June 2014

  Author:

    John Burkardt

  Reference:

    Dianne O'Leary,
    Scientific Computing with Case Studies,
    SIAM, 2008,
    ISBN13: 978-0-898716-66-5,
    LC: QA401.O44.
*/
{
  int i;
  int n = 11;
  double e1;
  double e2;
  double h1s;
  double mx;
  double *u;
  double uexact;
  double *x;
  double x_first;
  double x_last;

  printf ( "\n" );
  printf ( "TEST09\n" );
  printf ( "  Solve -( A(x) U'(x) )' + C(x) U(x) = F(x)\n" );
  printf ( "  for 0 < x < 1, with U(0) = U(1) = 0.\n" );
  printf ( "  A9(X) = 1.0\n" );
  printf ( "  C9(X) = 0.0\n" );
  printf ( "  F9(X) = X * ( X + 3 ) * exp ( X ),   X <= 2/3\n" );
  printf ( "        = 2 * exp ( 2/3),                   2/3 < X\n" );
  printf ( "  U9(X) = X * ( 1 - X ) * exp ( X ),   X <= 2/3\n" );
  printf ( "        = X * ( 1 - X ),                    2/3 < X\n" );
  printf ( "\n" );
  printf ( "  Number of nodes = %d\n", n );
/*
  Geometry definitions.
*/
  x_first = 0.0;
  x_last = 1.0;
  x = r8vec_linspace_new ( n, x_first, x_last );

  u = fem1d_bvp_linear ( n, a9, c9, f9, x );

  printf ( "\n" );
  printf ( "     I    X         U         Uexact    Error\n" );
  printf ( "\n" );

  for ( i = 0; i < n; i++ )
  {
    uexact = exact9 ( x[i] );
    printf ( "  %4d  %8f  %14f  %14f %14e\n", 
      i, x[i], u[i], uexact, fabs ( u[i] - uexact ) );
  }

  e1 = l1_error ( n, x, u, exact9 );
  e2 = l2_error_linear ( n, x, u, exact9 );
  h1s = h1s_error_linear ( n, x, u, exact_ux9 );
  mx = max_error_linear ( n, x, u, exact9 );
  printf ( "\n" );
  printf ( "  l1 norm of error  = %g\n", e1 );
  printf ( "  L2 norm of error  = %g\n", e2 );
  printf ( "  Seminorm of error = %g\n", h1s );
  printf ( "  Max norm of error = %g\n", mx );

  free ( u );
  free ( x );

  return;
}
/******************************************************************************/

double a9 ( double x )

/******************************************************************************/
/*
  Purpose:

    A9 evaluates A function #9.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    16 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double A9, the value of A(X).
*/
{
  double value;

  value = 1.0;

  return value;
}
/******************************************************************************/

double c9 ( double x )

/******************************************************************************/
/*
  Purpose:

    C9 evaluates C function #9.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    16 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double C9, the value of C(X).
*/
{
  double value;

  value = 0.0;

  return value;
}
/******************************************************************************/

double exact9 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT9 evaluates exact solution #9.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    16 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT9, the value of U(X).
*/
{
  double value;

  if ( x <= 2.0 / 3.0 )
  {
    value = x * ( 1.0 - x ) * exp ( x );
  }
  else
  {
    value = x * ( 1.0 - x );
  }

  return value;
}
/******************************************************************************/

double exact_ux9 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT_UX9 evaluates the derivative of exact solution #9.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    16 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT_UX9, the value of dUdX(X).
*/
{
  double value;

  if ( x <= 2.0 / 3.0 )
  {
    value = ( 1.0 - x - x * x ) * exp ( x );
  }
  else
  {
    value = 1.0 - 2.0 * x;
  }

  return value;
}
/******************************************************************************/

double f9 ( double x )

/******************************************************************************/
/*
  Purpose:

    F9 evaluates right hand side function #9.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    16 June 2014

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double F9, the value of F(X).
*/
{
  double value;

  if ( x <= 2.0 / 3.0 )
  {
    value = x * ( x + 3.0 ) * exp ( x );
  }
  else
  {
    value = 2.0;
  }

  return value;
}
/******************************************************************************/

void test10 ( )

/******************************************************************************/
/*
  Purpose:

    TEST10 tests FEM1D_BVP_LINEAR.

  Discussion:

    We want to compute errors and do convergence rates for the 
    following problem:

    - uxx + u = x  for 0 < x < 1
    u(0) = u(1) = 0

    exact  = x - sinh(x) / sinh(1)
    exact' = 1 - cosh(x) / sinh(1)

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    10 July 2015

  Author:

    John Burkardt

  Reference:

    Dianne O'Leary,
    Scientific Computing with Case Studies,
    SIAM, 2008,
    ISBN13: 978-0-898716-66-5,
    LC: QA401.O44.
*/
{
  char command_filename[255];
  FILE *command_unit;
  char data_filename[255];
  FILE *data_unit;
  int e_log;
  int e_log_max = 6;
  double *h_plot;
  double h1;
  double *h1_plot;
  double l2;
  double *l2_plot;
  double mx;
  double *mx_plot;
  int n;
  int ne;
  int ne1;
  int ne2;
  int *ne_plot;
  char output_filename[255];
  double r;
  double *u;
  double *x;
  double x_hi;
  double x_lo;

  printf ( "\n" );
  printf ( "TEST10\n" );
  printf ( "  Solve -( A(x) U'(x) )' + C(x) U(x) = F(x)\n" );
  printf ( "  for 0 < x < 1, with U(0) = U(1) = 0.\n" );
  printf ( "  A(X)  = 1.0\n" );
  printf ( "  C(X)  = 1.0\n" );
  printf ( "  F(X)  = X\n" );
  printf ( "  U(X)  = X - SINH(X) / SINH(1)\n" );
  printf ( "\n" );
  printf ( " log(E)    E         L2error         H1error        Maxerror\n" );
  printf ( "\n" );

  h_plot = ( double * ) malloc ( ( e_log_max + 1 ) * sizeof ( double ) );
  h1_plot = ( double * ) malloc ( ( e_log_max + 1 ) * sizeof ( double ) );
  l2_plot = ( double * ) malloc ( ( e_log_max + 1 ) * sizeof ( double ) );
  mx_plot = ( double * ) malloc ( ( e_log_max + 1 ) * sizeof ( double ) );
  ne_plot = ( int * ) malloc ( ( e_log_max + 1 ) * sizeof ( int ) );
  
  for ( e_log = 0; e_log <= e_log_max; e_log++ )
  {
    ne = i4_power ( 2, e_log );

    n = ne + 1;
    x_lo = 0.0;
    x_hi = 1.0;
    x = r8vec_linspace_new ( n, x_lo, x_hi );

    u = fem1d_bvp_linear ( n, a10, c10, f10, x );

    ne_plot[e_log] = ne;

    h_plot[e_log] = ( x_hi - x_lo ) / ( double ) ( ne );

    l2 = l2_error_linear ( n, x, u, exact10 );
    l2_plot[e_log] = l2;

    h1 = h1s_error_linear ( n, x, u, exact_ux10 );
    h1_plot[e_log] = h1;

    mx = max_error_linear ( n, x, u, exact10 );
    mx_plot[e_log] = mx;

    printf ( "  %4d  %4d  %14.6g  %14.6g  %14.6g\n", e_log, ne, l2, h1, mx );

    free ( u );
    free ( x );
  }

  printf ( "\n" );
  printf ( " log(E1)  E1 / E2          L2rate          H1rate         Maxrate\n" );
  printf ( "\n" );

  for ( e_log = 0; e_log < e_log_max; e_log++ )
  {
    ne1 = ne_plot[e_log];
    ne2 = ne_plot[e_log+1];
    r = ( double ) ( ne2 ) / ( double ) ( ne1 );
    l2 = l2_plot[e_log] / l2_plot[e_log+1];
    l2 = log ( l2 ) / log ( r );
    h1 = h1_plot[e_log] / h1_plot[e_log+1];
    h1 = log ( h1 ) / log ( r );
    mx = mx_plot[e_log] / mx_plot[e_log+1];
    mx = log ( mx ) / log ( r );
    printf ( "  %4d  %4d / %4d  %14.6g  %14.6g  %14.6g\n", 
      e_log, ne1, ne2, l2, h1, mx );
  }
/*
  Create the data file.
*/
  strcpy ( data_filename, "data.txt" );
  data_unit = fopen ( data_filename, "wt" );
  for ( e_log = 0; e_log <= e_log_max; e_log++ )
  {
    fprintf ( data_unit, "  %d  %g  %g  %g\n", 
      ne_plot[e_log], l2_plot[e_log], h1_plot[e_log], mx_plot[e_log] );
  }
  fclose ( data_unit );
  printf ( "\n" );
  printf ( "  Created graphics data file \"%s\".\n", data_filename );
/*
  Plot the L2 error as a function of NE.
*/
  strcpy ( command_filename, "commands_l2.txt" );
  command_unit = fopen ( command_filename, "wt" );

  strcpy ( output_filename, "l2.png" );

  fprintf ( command_unit, "# %s\n", command_filename );
  fprintf ( command_unit, "#\n" );
  fprintf ( command_unit, "# Usage:\n" );
  fprintf ( command_unit, "#  gnuplot < %s\n", command_filename );
  fprintf ( command_unit, "#\n" );
  fprintf ( command_unit, "set term png\n" );
  fprintf ( command_unit, "set output '%s'\n", output_filename );
  fprintf ( command_unit, "set xlabel '<---NE--->'\n" );
  fprintf ( command_unit, "set ylabel '<---L2(NE)--->'\n" );
  fprintf ( command_unit, "set title 'L2 error versus number of elements NE'\n" );
  fprintf ( command_unit, "set logscale xy\n" );
  fprintf ( command_unit, "set size ratio -1\n" );
  fprintf ( command_unit, "set grid\n" );
  fprintf ( command_unit, "set style data lines\n" );
  fprintf ( command_unit, "plot '%s' using 1:2 with points pt 7 ps 2 lc rgb 'blue',\\\n",
    data_filename );
  fprintf ( command_unit, "     '%s' using 1:2 lw 3 linecolor rgb 'red'\n", 
    data_filename );

  fclose ( command_unit );
  printf ( "  Created graphics command file \"%s\".\n", command_filename );
/*
  Plot the H1 error as a function of NE.
*/
  strcpy ( command_filename, "commands_h1.txt" );
  command_unit = fopen ( command_filename, "wt" );

  strcpy ( output_filename, "h1.png" );

  fprintf ( command_unit, "# %s\n", command_filename );
  fprintf ( command_unit, "#\n" );
  fprintf ( command_unit, "# Usage:\n" );
  fprintf ( command_unit, "#  gnuplot < %s\n", command_filename );
  fprintf ( command_unit, "#\n" );
  fprintf ( command_unit, "set term png\n" );
  fprintf ( command_unit, "set output '%s'\n", output_filename );
  fprintf ( command_unit, "set xlabel '<---NE--->'\n" );
  fprintf ( command_unit, "set ylabel '<---H1(NE)--->'\n" );
  fprintf ( command_unit, "set title 'H1 error versus number of elements NE'\n" );
  fprintf ( command_unit, "set logscale xy\n" );
  fprintf ( command_unit, "set size ratio -1\n" );
  fprintf ( command_unit, "set grid\n" );
  fprintf ( command_unit, "set style data lines\n" );
  fprintf ( command_unit, "plot '%s' using 1:3 with points pt 7 ps 2 lc rgb 'blue',\\\n",
    data_filename );
  fprintf ( command_unit, "     '%s' using 1:3 lw 3 linecolor rgb 'red'\n", 
    data_filename );

  fclose ( command_unit );
  printf ( "  Created graphics command file \"%s\".\n", command_filename );
/*
  Plot the MX error as a function of NE.
*/
  strcpy ( command_filename, "commands_mx.txt" );
  command_unit = fopen ( command_filename, "wt" );

  strcpy ( output_filename, "mx.png" );

  fprintf ( command_unit, "# %s\n", command_filename );
  fprintf ( command_unit, "#\n" );
  fprintf ( command_unit, "# Usage:\n" );
  fprintf ( command_unit, "#  gnuplot < %s\n", command_filename );
  fprintf ( command_unit, "#\n" );
  fprintf ( command_unit, "set term png\n" );
  fprintf ( command_unit, "set output '%s'\n", output_filename );
  fprintf ( command_unit, "set xlabel '<---NE--->'\n" );
  fprintf ( command_unit, "set ylabel '<---MX(NE)--->'\n" );
  fprintf ( command_unit, "set title 'Max error versus number of elements NE'\n" );
  fprintf ( command_unit, "set logscale xy\n" );
  fprintf ( command_unit, "set size ratio -1\n" );
  fprintf ( command_unit, "set grid\n" );
  fprintf ( command_unit, "set style data lines\n" );
  fprintf ( command_unit, "plot '%s' using 1:4 with points pt 7 ps 2 lc rgb 'blue',\\\n",
    data_filename );
  fprintf ( command_unit, "     '%s' using 1:4 lw 3 linecolor rgb 'red'\n", 
    data_filename );

  fclose ( command_unit );
  printf ( "  Created graphics command file \"%s\".\n", command_filename );
/*
  Free memory.
*/
  free ( h_plot );
  free ( h1_plot );
  free ( l2_plot );
  free ( mx_plot );
  free ( ne_plot );

  return;
}
/******************************************************************************/

double a10 ( double x )

/******************************************************************************/
/*
  Purpose:

    A10 evaluates A function #10.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    18 July 2015

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double A10, the value of A(X).
*/
{
  double value;

  value = 1.0;

  return value;
}
/******************************************************************************/

double c10 ( double x )

/******************************************************************************/
/*
  Purpose:

    C10 evaluates C function #10.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    18 July 2015

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double C10, the value of C(X).
*/
{
  double value;

  value = 1.0;

  return value;
}
/******************************************************************************/

double exact10 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT10 evaluates exact solution #10.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    18 July 2015

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT10, the value of U(X).
*/
{
  double value;

  value = x - sinh ( x ) / sinh ( 1.0 );

  return value;
}
/******************************************************************************/

double exact_ux10 ( double x )

/******************************************************************************/
/*
  Purpose:

    EXACT_UX10 evaluates the derivative of exact solution #10.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    18 July 2015

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double EXACT_UX10, the value of dUdX(X).
*/
{
  double value;

  value = 1.0 - cosh ( x ) / sinh ( 1.0 );

  return value;
}
/******************************************************************************/

double f10 ( double x )

/******************************************************************************/
/*
  Purpose:

    F10 evaluates right hand side function #10.

  Licensing:

    This code is distributed under the GNU LGPL license.

  Modified:

    18 July 2015

  Author:

    John Burkardt

  Parameters:

    Input, double X, the evaluation point.

    Output, double F10, the value of F(X).
*/
{
  double value;

  value = x;

  return value;
}