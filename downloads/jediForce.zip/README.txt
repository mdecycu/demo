

This tutorial aims at controlling a V-REP simulation (http:www.coppeliarobotics.com) through a serial port, with an Arduino Mega 2560, collecting heading data from a magnetic compass HMC6352 and the distance to an obstacle with a Sharp GP2D12 PSD sensor.

We can push and rotate (Jedi style ;) ) the cube, inside the V-REP simulation.

Please find the video tutorial using these files at

http://youtu.be/ZJQV2FlGFBo
