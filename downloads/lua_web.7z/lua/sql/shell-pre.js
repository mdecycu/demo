// This prevents pollution of the global namespace
var SQL = (function () {
