import NXOpen
import NXOpen.UF
import NXOpen.Gateway
import string
import random
import sys

#print(sys.argv)

def password_generator(size=4, chars=string.ascii_lowercase + string.digits):
    # 函式內以多行註解說明函式功能
    """Generate random password
    """
    # 利用 return 關鍵字將所產生的亂數字串傳回
    return ''.join(random.choice(chars) for _ in range(size))
'''
p7_new = "10"
p8_new = "20"
p9_new = "30"
'''
p7_new = sys.argv[1]
p8_new = sys.argv[2]
p9_new = sys.argv[3]

# 取得目前開啟的工作階段
theSession = NXOpen.Session.GetSession()
theUfSession = NXOpen.UF.UFSession.GetUFSession()

# 開啟零件檔案
basePart1 = theSession.Parts.OpenDisplay("C:/Users/cad2022/tmp/s/downloads/block.prt")
basePart1 = None
workPart = theSession.Parts.Work
unit1 = workPart.UnitCollection.FindObject("MilliMeter")
# height
p7 = workPart.Expressions.FindObject("p7")
# width
p8 = workPart.Expressions.FindObject("p8")
# length
p9 = workPart.Expressions.FindObject("p9")
# 若表單無法取值, 則採內定參數
try:
    workPart.Expressions.EditWithUnits(p7, unit1, p7_new)
    workPart.Expressions.EditWithUnits(p8, unit1, p8_new)
    workPart.Expressions.EditWithUnits(p9, unit1, p9_new)
except:
    workPart.Expressions.EditWithUnits(p7, unit1, "30")
    workPart.Expressions.EditWithUnits(p8, unit1, "60")
    workPart.Expressions.EditWithUnits(p9, unit1, "90")

theSession.UpdateManager.DoUpdate(0)
id = password_generator()
try:
    saveStatus1 = workPart.SaveAs("C:/Users/cad2022/tmp/s/downloads/block_" + id + ".prt")
    saveStatus1.Dispose()
except:
    pass
# initialize list to hold bodies
theBodyTags = []

for x in workPart.Bodies:
    if x.IsSolidBody:
        theBodyTags.append(x.Tag)
  
# 準備輸出 ASCII 格式 STL 零件檔案
sTLCreator1 = theSession.DexManager.CreateStlCreator()
sTLCreator1.AutoNormalGen = True
sTLCreator1.ChordalTol = 0.08
sTLCreator1.AdjacencyTol = 0.08
sTLCreator1.OutputFile = "C:/Users/cad2022/tmp/s/downloads/block_ascii.stl"
# Binary STL: NXOpen.STLCreatorOutputTypeEnum.Binary
sTLCreator1.OutputType = NXOpen.STLCreatorOutputTypeEnum.Text
# 已知 body1 命名
body1 = workPart.Bodies.FindObject("EXTRUDE(2)")
added1 = sTLCreator1.ExportSelectionBlock.Add(body1)
nXObject1 = sTLCreator1.Commit()
sTLCreator1.Destroy()

(massProps, Stats) = theUfSession.Modeling.AskMassProps3d(theBodyTags, len(theBodyTags), 1, 4, .03, 1, [0.99,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0])

surface_area = str(round(massProps[0]*1E6, 6))
volume = str(round(massProps[1]*1E9, 6))

# 將結果以 dict 字串存入檔案
with open("c:/tmp/ex/result.txt", "w") as f:
    f.write("{'id': '" + str(id) + "', 'surface_area': '" + str(surface_area) + "', " + "'volume': '" + str(volume) + "'}")
